car = input("お探しの車名を入力してください：")
print(f"{car}を探してみます。")