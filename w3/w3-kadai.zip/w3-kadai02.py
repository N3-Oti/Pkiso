like_num = {"Yamada":4,"Satou":5,"Utida":777,"Oda":50}

for name, num in like_num.items():
    print(f"{name}さんが好きな数字は{num}です。")