baisu = list(range(3,31,3))
for i in range(len(baisu)):
    print(f"{baisu[i]}")