wantgo = ["Google","Amazon","OpenAI","Microsoft","NTT"]
print(wantgo[0:3])
print(wantgo[(len(wantgo)//2)-1:(len(wantgo)//2)+2])
print(wantgo[len(wantgo)-3:])