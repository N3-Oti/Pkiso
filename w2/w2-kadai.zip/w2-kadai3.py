mill = list(range(1,1000001))
print(min(mill))
print(max(mill))
print(sum(mill))