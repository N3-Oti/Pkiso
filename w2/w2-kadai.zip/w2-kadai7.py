cube = [value**3 for value in range(1,11)]
for i in range(len(cube)):
    print(f"{cube[i]}")