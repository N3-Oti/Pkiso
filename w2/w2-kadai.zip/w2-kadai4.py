kisu = list(range(1,21,2))
for i in range(len(kisu)):
    print(f"{kisu[i]}")