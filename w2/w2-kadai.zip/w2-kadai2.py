mill = list(range(1,1000001))
for i in range(1,1000001):
    print(f"{mill[i]}")