def describe_city(name,kuni="japan"):#都市名関数
    print(f"{kuni}にある{name}")

describe_city(name="kobe")
describe_city("sinsen","china")
describe_city("fukuoka",)
