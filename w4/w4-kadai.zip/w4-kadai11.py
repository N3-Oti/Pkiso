def favorite_book(title):#好きな本表示関数
    print(f"私の好きな本の一つに、{title}があります。")

favorite_book("通帳")