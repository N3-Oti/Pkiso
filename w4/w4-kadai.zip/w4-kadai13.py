def Make_shirt(size="L",mes="I love Python"):#シャツのサイズとメッセージ関数
    print(f"{size}サイズ,印刷されるメッセージは[{mes}]です。")

Make_shirt()
Make_shirt(size="M")
Make_shirt("S","MiniSize")