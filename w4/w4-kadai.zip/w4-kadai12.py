def Make_shirt(size,mes):#シャツのサイズとメッセージ関数
    print(f"{size}サイズ,印刷されるメッセージは[{mes}]です。")

Make_shirt("L","okpk")
Make_shirt(size="M",mes="python")