def display_message(mes):#今日学んだことを表示する関数
    print(f"今日学んだことは{mes}です。")

display_message("python")